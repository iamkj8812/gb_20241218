package com.codingbox.web.dao;

import com.codingbox.web.dto.UserDTO;

public class UserDAO {
	// DB 접근에 대한 모든 항목을 작성
	
	// 회원가입
	public boolean join(UserDTO dto) {
		// DB 처리
		
		return true;
	}

}










