/**
 * 
 */
function sendit(){
	let frm = document.getElementById("joinForm");
	let idTag = document.getElementById("userid");
	let pwTag = document.getElementById("userpw");
	let nameTag = frm.username;
	let phoneTag = frm.userphone;	
		
	// 아이디 빈값 체크 		-> alert "아이디를 입력하세요!"
	if( idTag.value == "" ){
		alert("아이디를 입력하세요!");
		idTag.focus();
		return false;
	}	
	
	// 비밀번호 빈값 체크 		-> alert "비밀번호를 입력하세요!"
	if(pwTag.value == ""){
		alert("비밀번호를 입력하세요!");
		pwTag.focus();
		return false;
	}
	
	// 비밀번호 8자리 이상 체크	-> alert "비밀번호를 8자리 이상 입력하세요!"
	if(pwTag.value.length < 8){
		alert("비밀번호를 8자리 이상 입력하세요!");
		pwTag.focus();
		return false;
	}	
	
	// 이름 빈값 체크		-> alert "이름을 입력하세요!"
	if(nameTag.value == ""){
		alert("이름을 입력하세요!");
		nameTag.focus();
		return false;
	}
	
	// 휴대폰번호 빈값 체크	-> alert "휴대폰 번호를 입력하세요!"
	if(phoneTag.value == ""){
		alert("휴대폰 번호를 입력하세요");
		phoneTag.focus();
		return false;
	}
	
	// 전부 입력 후, submit();	
	frm.submit();
}






